from flask import Flask, request, jsonify, render_template
from googletrans import Translator


app = Flask(__name__)
translator = Translator()

@app.route('/')
def home():
    
    return render_template('index.html')

@app.route('/translate', methods=['POST'])
def translate():
    data = request.get_json()
    text = data.get('text')
    target_language = data.get('target_language')

    if not text or not target_language:
        return jsonify({"error": "Missing text or target_language parameter"}), 400

    try:
        translated = translator.translate(text, dest=target_language)
        translated_text = translated.text
        return jsonify({
            "original_text": text,
            "translated_text": translated_text,
            "target_language": target_language
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)



