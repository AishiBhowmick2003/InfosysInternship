function translateText() {
  
    var text = document.getElementById("text").value;
    var targetLanguage = document.getElementById("language").value;

    if (!text) {
        alert("Please enter text to translate.");
        return;
    }


    var xhr = new XMLHttpRequest();
    xhr.open("POST", "http://127.0.0.1:5000/translate", true);
    xhr.setRequestHeader("Content-Type", "application/json");

    var data = JSON.stringify({
        "text": text,
        "target_language": targetLanguage
    });

    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
            
            var response = JSON.parse(xhr.responseText);
            if (response.translated_text) {
                document.getElementById("translated-text").innerText = response.translated_text;
            } else {
                alert("Error: " + response.error);
            }
        }
    };

    xhr.send(data);
}
