import os
import pinecone
from langchain.embeddings import SentenceTransformerEmbeddings
from langchain.vectorstores import Pinecone
from langchain.document_loaders import PyPDFLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.prompts import PromptTemplate
from langchain.llms import CTransformers
from tqdm import tqdm
from dotenv import load_dotenv
import tempfile
import streamlit as st


load_dotenv()

PINECONE_API_KEY = os.getenv("pcsk_4h3HrQ_FuYkawtLs5fqJAK5v9QBBEyFwfJtgwaeteDnVY1HrRBBJVBfTY1nxAsc6HMEhxx")
PINECONE_ENVIRONMENT = os.getenv("us-east-1")
PINECONE_INDEX_NAME = "medical-chatbot"


pinecone.init(api_key=PINECONE_API_KEY, environment=PINECONE_ENVIRONMENT)


embeddings = SentenceTransformerEmbeddings(model_name="all-MiniLM-L6-v2")

if PINECONE_INDEX_NAME not in pinecone.list_indexes():
    pinecone.create_index(
        name=PINECONE_INDEX_NAME,
        dimension=embeddings.embedding_dim,
        metric="cosine"
    )

index = pinecone.Index(PINECONE_INDEX_NAME)


st.title("Medical Book Chatbot")


uploaded_file = st.file_uploader("Upload your medical book (PDF)", type="pdf")

if uploaded_file is not None:

    with tempfile.NamedTemporaryFile(delete=False, suffix='.pdf') as temp_file:
        temp_file.write(uploaded_file.getvalue())
        temp_file_path = temp_file.name

    st.write(f"Processing PDF: {temp_file_path}")

  
    try:
        loader = PyPDFLoader(temp_file_path)
        documents = loader.load()
    except Exception as e:
        st.error(f"Error loading PDF: {e}")
 
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=50)
    text_chunks = text_splitter.split_documents(documents)

    
    batch_size = 32
    for i in tqdm(range(0, len(text_chunks), batch_size)):
        batch = text_chunks[i:i + batch_size]
        metadatas = [doc.metadata for doc in batch]
        ids = [str(i) + '-' + str(j) for j in range(len(batch))]
        texts = [doc.page_content for doc in batch]

        try:
            embeddings_batch = embeddings.embed_documents(texts)
            index.upsert(vectors=zip(ids, embeddings_batch, metadatas))
        except Exception as e:
            st.error(f"Error during upsertion: {e}")

    st.success("Text chunks upserted to Pinecone.")
    st.write("PDF processing complete!")

 
    LLM_PATH = r"C:\Users\bhowm\Downloads\yolov9\llama-2-7b-chat.ggmlv3.q4_0.bin" 
    try:
        llm = CTransformers(model=LLM_PATH, model_type="llama", config={'max_new_tokens': 256, 'temperature': 0.6})
    except FileNotFoundError:
        st.error(f"Llama 2 model file not found: {LLM_PATH}. Please provide the correct path.")
    except Exception as e:
        st.error(f"Error loading Llama 2 model: {e}")

 
    template = """Use the given information context to give appropriate answer for the user's question.
    If you don't know the answer, just say that you don't know the answer.

    Context: {context}
    Question: {question}
    """
    prompt = PromptTemplate(template=template, input_variables=["context", "question"])


    def interact_with_chatbot(query):
        docsearch = Pinecone.from_existing_index(PINECONE_INDEX_NAME, embeddings)
        docs = docsearch.similarity_search(query, k=3)  
        context = "\n".join([doc.page_content for doc in docs])
        final_prompt = prompt.format(context=context, question=query)

        try:
            answer = llm(final_prompt)
            return answer
        except Exception as e:
            return f"Error during Llama 2 inference: {e}"

    # 6. User Interaction: Query
    query = st.text_area("Ask a question about the book:")

    if query:
        answer = interact_with_chatbot(query)
        st.write("Chatbot Response:")
        st.write(answer)

